let maxSlots = 12;
let currentSlots = 0;
let formData = {};

function shakeElement(el){ 
    el.classList.add('shake'); 
    setTimeout(()=>el.classList.remove('shake'),500); 
}

document.getElementById("tournamentForm").addEventListener("submit", function(e){
    e.preventDefault();
    if(currentSlots >= maxSlots){ 
        alert("❌ Registration Closed! All 12 slots are full."); 
        shakeElement(document.getElementById('step1')); 
        return; 
    }
    currentSlots++;
    formData.team = document.getElementById("teamName").value;
    formData.leader = document.getElementById("leaderName").value;
    formData.uid = document.getElementById("uid").value;
    formData.phone = document.getElementById("phone").value;

    alert(`✅ Slot Reserved! Slots filled: ${currentSlots}/${maxSlots}`);
    
    let upiLink = "upi://pay?pa=8140768305@naviaxis&pn=FreeFireTournament&am=1600&cu=INR";
    window.location.href = upiLink;

    document.getElementById("step1").style.display = "none";
    document.getElementById("step2").style.display = "block";

    if(currentSlots >= maxSlots){ 
        document.getElementById("tournamentForm").innerHTML = "<h3 style='color:red;'>❌ Registration Closed (12 Slots Full)</h3>"; 
    }
});

document.getElementById("utrForm").addEventListener("submit", function(e){
    e.preventDefault();
    formData.utr = document.getElementById("utr").value;
    let msg = `✅ New Tournament Registration%0A🔥 Team: ${formData.team}%0A👑 Leader: ${formData.leader}%0A🎮 UID: ${formData.uid}%0A📱 Phone: ${formData.phone}%0A💳 UTR: ${formData.utr}`;
    let wpLink = `https://wa.me/918140768305?text=${msg}`;
    window.open(wpLink, "_blank");
});

document.getElementById("copyMsgBtn").addEventListener("click", function(){
    let msgText = `✅ New Tournament Registration\n🔥 Team: ${formData.team}\n👑 Leader: ${formData.leader}\n🎮 UID: ${formData.uid}\n📱 Phone: ${formData.phone}\n💳 UTR: ${formData.utr}`;
    navigator.clipboard.writeText(msgText).then(()=>{
        alert("✅ WhatsApp message copied! Paste it in WhatsApp and send.");
    });
});